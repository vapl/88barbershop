"use client";

import React, { createContext, useContext, ReactNode } from "react";
// Importējam tipu, kas apraksta visus modālos logus
import { ModalData } from "@/lib/types";

// 1. Izveidojam Context, kurš sākumā ir tukšs (null)
const ModalContext = createContext<ModalData | null>(null);

// 2. Izveidojam "Provider" komponentu
// Tas saņems datus no servera un padarīs tos pieejamus visiem bērniem
export function ModalProvider({ children, modals }: { children: ReactNode; modals: ModalData }) {
  return <ModalContext.Provider value={modals}>{children}</ModalContext.Provider>;
}

// 3. Izveidojam "āķi" (hook), lai komponenti varētu viegli piekļūt datiem
export function useModals() {
  const context = useContext(ModalContext);
  if (context === null) {
    // Kļūda, ja mēģinām izmantot datus ārpus Provider
    throw new Error("useModals must be used within a ModalProvider");
  }
  return context;
}
