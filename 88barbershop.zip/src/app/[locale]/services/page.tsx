import { client } from "@/lib/sanityClient";
import { siteDataQuery } from "@/lib/sanityQuery";
import { adaptSanityData } from "@/lib/dataAdapter";

import Contacts from "@/components/sections/ContactsSection";
import HeroServices from "@/components/sections/HeroServices";
import ServicePricingSection from "@/components/sections/ServicePricingSection";

async function getSanityData() {
  const data = await client.fetch(siteDataQuery, {}, { next: { revalidate: 3600 } });
  return data;
}

export default async function ServicesPage() {
  const sanityData = await getSanityData();
  const siteData = adaptSanityData(sanityData);
  return (
    <>
      <HeroServices heroData={siteData.hero} />
      <ServicePricingSection serviceData={siteData.services} />
      <Contacts
        workingTime={siteData.working_time}
        contacts={siteData.contacts}
        contactsFormData={siteData.contact_form}
        errorsData={siteData.errors}
      />
    </>
  );
}
