import { client } from "@/lib/sanityClient";
import { siteDataQuery } from "@/lib/sanityQuery";
import { adaptSanityData } from "@/lib/dataAdapter";
import { ModalProvider } from "@/context/ModalContext";
import { hasLocale, NextIntlClientProvider } from "next-intl";
import { notFound } from "next/navigation";
import { routing } from "@/i18n/routing";
import Navbar from "@/components/navigation/Navbar";
import Footer from "@/components/sections/FooterSection";
import MobileActionButton from "@/components/ui/MobileActionButton";

type Props = {
  children: React.ReactNode;
  params: Promise<{ locale: string }> | { locale: string };
};

async function getSanityData() {
  const data = await client.fetch(siteDataQuery, {}, { next: { revalidate: 3600 } });
  return data;
}

export default async function LocaleLayout({ children, params }: Props) {
  const { locale } = await params;
  if (!hasLocale(routing.locales, locale)) {
    notFound();
  }

  const sanityData = await getSanityData();
  const siteData = adaptSanityData(sanityData);

  return (
    <NextIntlClientProvider locale={locale}>
      <ModalProvider modals={siteData.modals}>
        <Navbar navData={siteData.navigation} contactsData={siteData.contacts} />
        {children}
        <MobileActionButton contactsData={siteData.contacts} />
        <Footer
          footerData={siteData.footer}
          contactsData={siteData.contacts}
          navData={siteData.navigation}
          workingTimeData={siteData.working_time}
        />
      </ModalProvider>
    </NextIntlClientProvider>
  );
}
