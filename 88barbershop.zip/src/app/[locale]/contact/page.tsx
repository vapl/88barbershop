import { client } from "@/lib/sanityClient";
import { siteDataQuery } from "@/lib/sanityQuery";
import { adaptSanityData } from "@/lib/dataAdapter";

import MapEmbed from "@/components/MapEmbed";
import SectionHeading from "@/components/SectionHeading";
import Contacts from "@/components/sections/ContactsSection";
import HeroContact from "@/components/sections/HeroContact";
import { getLocale } from "next-intl/server";

async function getSanityData() {
  const data = await client.fetch(siteDataQuery, {}, { next: { revalidate: 3600 } });
  return data;
}

export default async function ContactPage() {
  const locale = (await getLocale()) as "lv" | "en" | "ru";

  const sanityData = await getSanityData();
  const siteData = adaptSanityData(sanityData);

  return (
    <>
      <HeroContact heroData={siteData.hero} />
      <div className="flex items-center justify-center px-4 md:px-16 lg:px-32 py-[80px]">
        <SectionHeading
          title={siteData.pages.contact_page.heading_intro[locale]}
          decoration={false}
          className="text-h3 md:text-h2"
          color="gold"
        />
      </div>
      <Contacts
        workingTime={siteData.working_time}
        contacts={siteData.contacts}
        contactsFormData={siteData.contact_form}
        errorsData={siteData.errors}
      />
      <section className="relative flex flex-col gap-[95px] items-center w-full text-background pt-[120px] bg-gradient-to-br from-background via-background-alt/80 to-background overflow-hidden">
        <SectionHeading
          title={siteData.pages.contact_page.heading_map[locale]}
          decoration={true}
          className="text-h3 md:text-h2"
          color="gold"
        />
        <MapEmbed />
      </section>
    </>
  );
}
