import { client } from "@/lib/sanityClient";
import { siteDataQuery } from "@/lib/sanityQuery";
import { adaptSanityData } from "@/lib/dataAdapter";

import ImagesCarousel from "@/components/carousel/ImagesCarousel";
import SectionHeading from "@/components/SectionHeading";
import AboutSection2 from "@/components/sections/AboutSection2";
import TeamSection from "@/components/sections/TeamSection";
import Contacts from "@/components/sections/ContactsSection";
import HeroAbout from "@/components/sections/HeroAbout";
import BusinessHighlightsSection from "@/components/sections/BusinessHighlightsSection";
import { getLocale } from "next-intl/server";

async function getSanityData() {
  const data = await client.fetch(siteDataQuery, {}, { next: { revalidate: 3600 } });
  return data;
}

export default async function AboutPage() {
  const locale = (await getLocale()) as "lv" | "en" | "ru";

  const sanityData = await getSanityData();
  const siteData = adaptSanityData(sanityData);

  return (
    <>
      <HeroAbout heroData={siteData.hero} />
      <div className="flex flex-col items-center justify-center px-4 md:px-16 lg:px-32 py-[80px] bg-background-alt">
        <SectionHeading
          title={siteData.pages.about_page.heading_intro[locale]}
          decoration={false}
          className="text-h3 md:text-h2"
          color="white"
        />
      </div>
      <BusinessHighlightsSection
        highlights={siteData.pages.about_page.businessHighlights}
        barbersCount={siteData.general.barbers.length}
      />
      <div className="bg-background-alt pb-[80px] overflow-hidden">
        <ImagesCarousel images={siteData.gallery} />
      </div>
      <AboutSection2 about={siteData.about} />
      <TeamSection
        heading={siteData.pages.about_page.heading_team}
        barbers={siteData.general.barbers}
      />
      <Contacts
        workingTime={siteData.working_time}
        contacts={siteData.contacts}
        contactsFormData={siteData.contact_form}
        errorsData={siteData.errors}
      />
    </>
  );
}
