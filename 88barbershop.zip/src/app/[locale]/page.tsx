import { client } from "@/lib/sanityClient";
import { siteDataQuery } from "@/lib/sanityQuery";
import { adaptSanityData } from "@/lib/dataAdapter";

import Contacts from "@/components/sections/ContactsSection";
import HeroSection from "@/components/sections/HeroSection";
import BarberRibbons from "@/components/sections/BarberRibbons";
import ServicesSection from "@/components/sections/ServicesSection";
import AboutSection from "@/components/sections/AboutSection";
import ReviewsSection from "@/components/sections/ReviewsSection";

async function getSanityData() {
  const data = await client.fetch(siteDataQuery, {}, { next: { revalidate: 3600 } });
  return data;
}

export default async function Home({ params: { locale } }: { params: { locale: string } }) {
  const sanityData = await getSanityData();
  const siteData = adaptSanityData(sanityData);

  return (
    <div className="relative">
      <HeroSection heroData={siteData.hero} />
      <BarberRibbons ribbonsData={siteData.ribbons} />
      <ServicesSection servicesData={siteData.services} />
      <AboutSection
        about={siteData.about}
        gallery={siteData.gallery}
        highlights={siteData.pages.about_page.businessHighlights}
      />
      <ReviewsSection reviewsSectionData={siteData.reviews} />
      <Contacts
        workingTime={siteData.working_time}
        contacts={siteData.contacts}
        contactsFormData={siteData.contact_form}
        errorsData={siteData.errors}
      />
    </div>
  );
}
