"use client";

import { NextStudio } from "next-sanity/studio";
// Importē savu Sanity konfigurāciju
import config from "../../../../studio-88barbershop/sanity.config";

export default function AdminPage() {
  // Renderē Sanity Studio komponentu
  return <NextStudio config={config} />;
}
