import { routing } from "./routing";

export const i18n = {
  locales: routing.locales,
  defaultLocale: routing.defaultLocale,
  messages: {},
};
